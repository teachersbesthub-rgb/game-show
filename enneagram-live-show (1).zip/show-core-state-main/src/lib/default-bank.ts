// Built-in fallback question bank (used if /questions.json cannot be loaded).
// To change questions without code: edit public/questions.json, or paste JSON in the host panel.
export const DEFAULT_BANK = {
  "title": "Coworkers",
  "questions": [
    {
      "id": "s01",
      "dim": "soc",
      "pole": 1,
      "q": "Who would turn a silent elevator ride into a full conversation?"
    },
    {
      "id": "s02",
      "dim": "soc",
      "pole": 1,
      "q": "Who would end up on a first-name basis with the building's security guard?"
    },
    {
      "id": "s03",
      "dim": "soc",
      "pole": 1,
      "q": "Who would be the first one on the dance floor at the company party?"
    },
    {
      "id": "s04",
      "dim": "soc",
      "pole": 1,
      "q": "Who would happily give a toast with zero notice?"
    },
    {
      "id": "s05",
      "dim": "soc",
      "pole": 1,
      "q": "Who would know someone at any event, even in a brand-new city?"
    },
    {
      "id": "s06",
      "dim": "soc",
      "pole": 1,
      "q": "Who would still be chatting 20 minutes after the meeting officially ended?"
    },
    {
      "id": "s07",
      "dim": "soc",
      "pole": 1,
      "q": "Who would pick the loudest table at the team lunch?"
    },
    {
      "id": "s08",
      "dim": "soc",
      "pole": 1,
      "q": "Who would introduce themselves to the new hire before anyone else?"
    },
    {
      "id": "s09",
      "dim": "soc",
      "pole": 1,
      "q": "Who would make friends with the stranger sitting next to them at the airport gate?"
    },
    {
      "id": "s10",
      "dim": "soc",
      "pole": -1,
      "q": "Who would slip out of the office party without anyone noticing?"
    },
    {
      "id": "s11",
      "dim": "soc",
      "pole": -1,
      "q": "Who would be happiest eating lunch alone with a book?"
    },
    {
      "id": "s12",
      "dim": "soc",
      "pole": -1,
      "q": "Who would rather send an email than walk over to talk?"
    },
    {
      "id": "w01",
      "dim": "warm",
      "pole": 1,
      "q": "Who would remember everyone's birthday without a reminder?"
    },
    {
      "id": "w02",
      "dim": "warm",
      "pole": 1,
      "q": "Who would notice you were having a bad day before you said a word?"
    },
    {
      "id": "w03",
      "dim": "warm",
      "pole": 1,
      "q": "Who would bring soup to a coworker who is out sick?"
    },
    {
      "id": "w04",
      "dim": "warm",
      "pole": 1,
      "q": "Who would give up their parking spot for someone having a rough week?"
    },
    {
      "id": "w05",
      "dim": "warm",
      "pole": 1,
      "q": "Who would everyone vent to after a tough meeting?"
    },
    {
      "id": "w06",
      "dim": "warm",
      "pole": 1,
      "q": "Who would write the most heartfelt farewell card for a leaving colleague?"
    },
    {
      "id": "w07",
      "dim": "warm",
      "pole": 1,
      "q": "Who would stay late to help someone else finish their work?"
    },
    {
      "id": "w08",
      "dim": "warm",
      "pole": 1,
      "q": "Who would stand up for a teammate who is being unfairly blamed?"
    },
    {
      "id": "w09",
      "dim": "warm",
      "pole": 1,
      "q": "Who would split their lunch with someone who forgot theirs?"
    },
    {
      "id": "w10",
      "dim": "warm",
      "pole": -1,
      "q": "Who would tell you your idea won't work, with zero cushioning?"
    },
    {
      "id": "w11",
      "dim": "warm",
      "pole": -1,
      "q": "Who would choose the efficient answer over the friendly one every time?"
    },
    {
      "id": "w12",
      "dim": "warm",
      "pole": -1,
      "q": "Who would deliver bad news with absolutely no sugar-coating?"
    },
    {
      "id": "r01",
      "dim": "rel",
      "pole": 1,
      "q": "Who would have the suitcase packed the night before the trip?"
    },
    {
      "id": "r02",
      "dim": "rel",
      "pole": 1,
      "q": "Who would have a backup plan for the backup plan?"
    },
    {
      "id": "r03",
      "dim": "rel",
      "pole": 1,
      "q": "Who would arrive early to a meeting they are not even running?"
    },
    {
      "id": "r04",
      "dim": "rel",
      "pole": 1,
      "q": "Who would still have every receipt from the last three years?"
    },
    {
      "id": "r05",
      "dim": "rel",
      "pole": 1,
      "q": "Who would color-code the team calendar just for fun?"
    },
    {
      "id": "r06",
      "dim": "rel",
      "pole": 1,
      "q": "Who would finish the project days before the deadline?"
    },
    {
      "id": "r07",
      "dim": "rel",
      "pole": 1,
      "q": "Who would never lose their keys, phone, or wallet?"
    },
    {
      "id": "r08",
      "dim": "rel",
      "pole": 1,
      "q": "Who would read the entire instruction manual before touching the machine?"
    },
    {
      "id": "r09",
      "dim": "rel",
      "pole": 1,
      "q": "Who would already have next month's tasks planned out?"
    },
    {
      "id": "r10",
      "dim": "rel",
      "pole": -1,
      "q": "Who would be the last to arrive at the meeting, coffee in hand?"
    },
    {
      "id": "r11",
      "dim": "rel",
      "pole": -1,
      "q": "Who would finish the presentation five minutes before presenting it?"
    },
    {
      "id": "r12",
      "dim": "rel",
      "pole": -1,
      "q": "Who would be digging through their bag for their badge every morning?"
    },
    {
      "id": "c01",
      "dim": "calm",
      "pole": 1,
      "q": "Who would stay relaxed through a four-hour flight delay?"
    },
    {
      "id": "c02",
      "dim": "calm",
      "pole": 1,
      "q": "Who would stay cool when the projector dies mid-presentation?"
    },
    {
      "id": "c03",
      "dim": "calm",
      "pole": 1,
      "q": "Who would sleep soundly the night before a huge deadline?"
    },
    {
      "id": "c04",
      "dim": "calm",
      "pole": 1,
      "q": "Who would laugh off a mistake in front of the whole company?"
    },
    {
      "id": "c05",
      "dim": "calm",
      "pole": 1,
      "q": "Who would calmly handle an angry customer on the phone?"
    },
    {
      "id": "c06",
      "dim": "calm",
      "pole": 1,
      "q": "Who would stay peaceful when the group chat turns into a fight?"
    },
    {
      "id": "c07",
      "dim": "calm",
      "pole": 1,
      "q": "Who would be completely unbothered if the whole office lost Wi-Fi?"
    },
    {
      "id": "c08",
      "dim": "calm",
      "pole": 1,
      "q": "Who would take a surprise audit completely in stride?"
    },
    {
      "id": "c09",
      "dim": "calm",
      "pole": 1,
      "q": "Who would keep smiling when the client changes everything at the last minute?"
    },
    {
      "id": "c10",
      "dim": "calm",
      "pole": -1,
      "q": "Who would start worrying the moment they see a meeting titled 'Quick chat'?"
    },
    {
      "id": "c11",
      "dim": "calm",
      "pole": -1,
      "q": "Who would re-read a sent email three times to check the tone?"
    },
    {
      "id": "c12",
      "dim": "calm",
      "pole": -1,
      "q": "Who would pace the hallway before a big presentation?"
    },
    {
      "id": "o01",
      "dim": "open",
      "pole": 1,
      "q": "Who would order the strangest item on the menu?"
    },
    {
      "id": "o02",
      "dim": "open",
      "pole": 1,
      "q": "Who would try a new app or tool the day it launches?"
    },
    {
      "id": "o03",
      "dim": "open",
      "pole": 1,
      "q": "Who would always have a wild idea ready for a brainstorm?"
    },
    {
      "id": "o04",
      "dim": "open",
      "pole": 1,
      "q": "Who would recommend a weird book or podcast nobody has heard of?"
    },
    {
      "id": "o05",
      "dim": "open",
      "pole": 1,
      "q": "Who would take a different route to work just to see something new?"
    },
    {
      "id": "o06",
      "dim": "open",
      "pole": 1,
      "q": "Who would turn a boring task into a creative experiment?"
    },
    {
      "id": "o07",
      "dim": "open",
      "pole": 1,
      "q": "Who would sign up for a class in something totally unrelated to their job?"
    },
    {
      "id": "o08",
      "dim": "open",
      "pole": 1,
      "q": "Who would decorate their desk in a way nobody else would think of?"
    },
    {
      "id": "o09",
      "dim": "open",
      "pole": 1,
      "q": "Who would suggest a team activity nobody has ever heard of?"
    },
    {
      "id": "o10",
      "dim": "open",
      "pole": -1,
      "q": "Who would order the same lunch every single day?"
    },
    {
      "id": "o11",
      "dim": "open",
      "pole": -1,
      "q": "Who would pick the proven method over the experiment every time?"
    },
    {
      "id": "o12",
      "dim": "open",
      "pole": -1,
      "q": "Who would politely resist every new software update?"
    }
  ]
} as const;
